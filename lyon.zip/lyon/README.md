# Bienvenue sur le dépot gitlab de la finale de Cod'INSA 2021 de l'équipe Lyon
Vous devrez déposer ici vos solutions (code exécutable) pour répondre au sujet de la finale 2021. Vous avez jusqu'au dimanche 23 mai 2021, à 19h30 précises pour rendre vos codes

## Documentation du sujet
|Version        |Date heure     |lien |
| :--------------- |:---------------:| -----:|
| 1|22/05 15h30 |https://drive.google.com/file/d/1an8mo_1nowGP6dou8U79EBBnEiIj4bUR/view?usp=sharing |
| 2|22/05 16h |https://drive.google.com/file/d/1os6bqkWkEB67eXL8NOBMDI6xvpJ8dyR8/view?usp=sharing|
|3|22/05 19h15|https://drive.google.com/file/d/1YVJczjsQTFAAp1m7UxNXZ9uSSL6Zq0BB/view?usp=sharing|

## Codes de connexion au serveur de test
Vous devrez vous connecter à http://codinsa.insa-rennes.fr/init, en post avec un dictionnaire Json (avec les clefs “username” et “password”):
|username|password|
| :--------------- | -----:|
|Lyon1| `g[B>!&I7C#V;-Y,OW%+/9A5` |
|Lyon2| `ET1j]ZWe(JY)^A4_#@_1.h_J` |
|Lyon3| `0%%IFIJ^&_Ac#_>R,a_YA+'` |
